# Aseprite Translations

Aseprite is translated using the following Weblate project:

  https://hosted.weblate.org/projects/aseprite/aseprite/

You can find all the translations in this other repository:

  https://github.com/aseprite/strings

The official English strings are from the [`en.ini` file here](https://github.com/aseprite/aseprite/blob/main/data/strings/en.ini),
and this file will be copied to the [strings repository](https://github.com/aseprite/strings/blob/main/en.ini) regularly.
